# IndecTech-Web
This website is indec tech home website
This website contains the information about indec, services, and Products details
Its a public website, The user who can access in publicly
